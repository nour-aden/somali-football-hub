# Jigjiga Bajaj

A runnable Node.js + SQLite starter for a Jigjiga bajaj ride-booking service. The interface is Somali-first and responsive.

## Included
- Customer ride booking and reference-based status lookup.
- Persistent SQLite booking database.
- Driver application and approval flow.
- Driver login, availability toggle, booking acceptance, and ride status changes.
- Admin dashboard for drivers, bookings, cancellation, assignment, fare settings, and basic recorded fare totals.
- Password hashing, session cookies, basic security headers, API rate limiting, and server-side role checks.

## Requirements
- Node.js 20 or newer
- npm

## Run locally
1. Extract the ZIP.
2. Copy `.env.example` to `.env`.
3. Change `SESSION_SECRET` to a long random value.
4. Set a strong `ADMIN_PASSWORD` and a unique `ADMIN_PHONE`.
5. In the project folder run:
   ```bash
   npm install
   npm start
   ```
6. Open `http://localhost:3000`.

The database is created automatically in `data/jigjiga-bajaj.sqlite`. The initial admin is created from `.env` on first startup if that phone number does not already exist.

## First use
1. Log in through “Darawal / Maamul” using `ADMIN_PHONE` and `ADMIN_PASSWORD`.
2. Register your driver account using “Noqo darawal”. An administrator must approve it.
3. Approve the driver from the admin dashboard.
4. Submit a customer booking from the homepage.
5. Accept and update the booking from the driver dashboard.

## Important limitations before a real public launch
This is a functional starter, not a fully audited production ride-hailing service.
- Fare shown is the configured base fare only. No distance-routing API is integrated yet, so it is not a true distance-based quote.
- Map selection, live GPS tracking, SMS OTP, payment gateway, automated WhatsApp notifications, and push notifications are not implemented.
- Customer status is refreshed manually by rechecking the reference; real-time updates are not implemented.
- Admin assignment currently asks for the approved driver's database ID.
- Before public deployment, add HTTPS, reliable backups, stronger operational monitoring, a password-reset process, privacy/retention policies, and professional security review.
- For production, configure `NODE_ENV=production`, a strong random `SESSION_SECRET`, and secure hosting. Never commit `.env` or the `data/` directory to source control.
- SQLite is suitable for an initial low-volume deployment. Consider PostgreSQL and transactional deployment infrastructure as usage grows.

## Deployment
Use a Node.js host that supports persistent disk storage. Ensure the `data/` directory persists across restarts and deployments. Configure environment variables in the host dashboard rather than uploading `.env`. If the host uses ephemeral filesystems, SQLite data may be lost; use a managed persistent database instead.

## Configuration
- `ADMIN_NAME`, `ADMIN_PHONE`, `ADMIN_PASSWORD`: initial administrator.
- `SESSION_SECRET`: secure session signing secret.
- `BASE_FARE`: provisional base fare shown to customers.
- `PER_KM_FARE`: stored configurable pricing setting for future distance calculation.
- `BUSINESS_PHONE`: optional phone/WhatsApp contact number, digits with country code recommended.

No real customer, driver, business contact, or fare data is preloaded.
