const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const modal = $("#modal"), modalContent = $("#modalContent");
$("#year").textContent = new Date().getFullYear();
let currentUser = null;
const statusSo = {pending:"Sugaya darawal",accepted:"Darawal ayaa aqbalay",arriving:"Darawalku wuu soo socdaa",in_progress:"Safarku wuu socdaa",completed:"Safarku wuu dhammaaday",cancelled:"Waa la joojiyey"};
function showResult(el, message, ok=false) { el.className = "result " + (ok?"success":"error"); el.textContent = message; }
async function api(url, options={}) {
 const res = await fetch(url,{...options,headers:{"Content-Type":"application/json",...(options.headers||{})}});
 const data = await res.json().catch(()=>({error:"Jawaabta server-ka lama akhrin karin."}));
 if(!res.ok) throw new Error(data.error || "Wax baa khaldamay.");
 return data;
}
function openModal(html) { modalContent.innerHTML=html; modal.classList.add("open"); }
function closeModal(){modal.classList.remove("open");}
$("#closeModal").addEventListener("click",closeModal);
modal.addEventListener("click",e=>{if(e.target===modal)closeModal()});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});
$("#menuBtn").addEventListener("click",()=>openModal(`<h2>Jigjiga Bajaj</h2><p><a href="#book" class="switch-link">Dalbo bajaj</a><a href="#how" class="switch-link">Sida uu u shaqeeyo</a><a href="#driver" class="switch-link">Noqo darawal</a></p><button class="btn btn-primary" id="menuLogin">Darawal / Maamul</button>`));
document.addEventListener("click",e=>{if(e.target.id==="menuLogin"){closeModal();showLogin()}});
async function loadSettings(){try{const s=await api("/api/settings");$("#fare").textContent=`${s.baseFare} ETB`;if(!s.serviceEnabled){$("#bookingForm").querySelector("button[type=submit]").disabled=true;$("#bookingForm").querySelector("button[type=submit]").textContent="Dalabku hadda wuu xiran yahay"}if(s.businessPhone){$("#contactBtn").href=`https://wa.me/${s.businessPhone.replace(/\D/g,"")}`;$("#contactBtn").target="_blank";$("#contactBtn").rel="noopener"}}catch(e){$("#fare").textContent="— ETB"}}
loadSettings();

$("#bookingForm").addEventListener("submit",async e=>{
 e.preventDefault();const form=e.currentTarget, result=$("#bookingResult"), button=form.querySelector("button[type=submit]");
 button.disabled=true;button.textContent="Waa la dirayaa…";result.className="result";result.textContent="";
 const values=Object.fromEntries(new FormData(form).entries());
 try{
  const data=await api("/api/bookings",{method:"POST",body:JSON.stringify(values)});
  showResult(result,`Dalabka waa la diiwaangeliyey! Lambarkaaga: ${data.reference}. Qiimaha bilowga ah: ${data.estimatedFare} ETB. Lambarkan hayso si aad xaaladda ula socoto.`,true);
  form.reset();result.innerHTML += ` <button type="button" class="btn btn-ghost" id="trackThis" data-ref="${data.reference}">La soco dalabkan</button>`;
 }catch(err){showResult(result,err.message)}
 finally{button.disabled=false;button.innerHTML='Dalbo bajaj <span>→</span>'}
});
document.addEventListener("click",e=>{if(e.target.id==="trackThis"){closeModal();$("#trackForm").reference.value=e.target.dataset.ref;$("#trackForm").requestSubmit();$("#trackForm").scrollIntoView({behavior:"smooth",block:"center"})}});
$("#trackForm").addEventListener("submit",async e=>{
 e.preventDefault();const result=$("#trackResult"),ref=e.currentTarget.reference.value.trim().toUpperCase();
 try{const data=await api("/api/bookings/"+encodeURIComponent(ref));const b=data.booking;
 result.className="result success";result.innerHTML=`<strong>${b.reference}</strong> · <span class="pill">${statusSo[b.status]||b.status}</span><br>Ka: ${escapeHtml(b.pickup)}<br>Ku: ${escapeHtml(b.destination)}<br>Qiime bilow ah: ${b.estimated_fare} ETB${b.driver?`<br>Darawal: ${escapeHtml(b.driver.name)} · ${escapeHtml(b.driver.phone)}`:""}${b.driver?.phone?`<br><a href="tel:${escapeHtml(b.driver.phone)}">Wac darawalka</a>`:""}`;
 }catch(err){showResult(result,err.message)}
});
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function showLogin(){openModal(`<h2>Ku gal akoonkaaga</h2><p>Darawalka iyo maamulka.</p><form id="loginForm"><label>Telefoonka<input name="phone" required autocomplete="username"></label><label>Furaha sirta<input name="password" type="password" required autocomplete="current-password"></label><button class="btn btn-primary">Gal akoonka</button><div id="loginResult" class="result"></div></form><span class="switch-link" id="forgotHint">Maamuluhu waa inuu dejiyo akoonka server-ka.</span>`)}
$("#openLogin").addEventListener("click",showLogin);
$("#openRegister").addEventListener("click",showRegister);
function showRegister(){openModal(`<h2>Noqo darawal</h2><p>Codsigaaga waa la eegi doonaa ka hor intaadan dalabyo aqbalin.</p><form id="registerForm"><label>Magaca oo buuxa<input name="name" required maxlength="160"></label><label>Telefoonka<input name="phone" required type="tel" maxlength="20"></label><label>Furaha sirta (ugu yaraan 10 xaraf)<input name="password" required type="password" minlength="10" autocomplete="new-password"></label><label>Lambarka bajajka / plate<input name="vehiclePlate" required maxlength="160"></label><label>Nooca ama aqoonsiga bajajka<input name="vehicleModel" required maxlength="160"></label><button class="btn btn-primary">Dir codsiga</button><div id="registerResult" class="result"></div></form>`)}
document.addEventListener("submit",async e=>{
 if(e.target.id==="loginForm"){
  e.preventDefault();const form=e.target;
  try{const data=await api("/api/login",{method:"POST",body:JSON.stringify(Object.fromEntries(new FormData(form).entries()))});currentUser=data.user;await renderDashboard();}catch(err){showResult($("#loginResult"),err.message)}
 }
 if(e.target.id==="registerForm"){
  e.preventDefault();try{const data=await api("/api/register-driver",{method:"POST",body:JSON.stringify(Object.fromEntries(new FormData(e.target).entries()))});showResult($("#registerResult"),data.message,true);e.target.reset()}catch(err){showResult($("#registerResult"),err.message)}
 }
});
async function renderDashboard(){
 if(!currentUser){showLogin();return}
 if(currentUser.role==="admin")return renderAdmin();
 if(currentUser.role==="driver")return renderDriver();
}
async function logout(){await api("/api/logout",{method:"POST",body:"{}"});currentUser=null;closeModal()}
function dashboardHeader(title){return `<h2>${title}</h2><p>Ku soo dhowow, ${escapeHtml(currentUser.name)}.</p><button class="btn btn-ghost" id="logoutBtn">Ka bax</button>`}
document.addEventListener("click",e=>{if(e.target.id==="logoutBtn")logout();if(e.target.id==="refreshDash")renderDashboard()});
async function renderDriver(){
 try{
 const data=await api("/api/driver/bookings");
 openModal(`${dashboardHeader("Dashboard-ka darawalka")}<p><span class="pill">${currentUser.approved?"La ansixiyey":"Sugaya ansixin"}</span></p><button class="btn btn-ghost" id="toggleOnline">${currentUser.online?"Ka bax online":"Noqo online"}</button><button class="btn btn-ghost" id="refreshDash">Cusboonaysii</button><h3>Dalabyada cusub</h3><div class="dashboard-wrap">${data.available.length?data.available.map(b=>`<article class="dash-card"><strong>${escapeHtml(b.reference)}</strong><small>${escapeHtml(b.customer_name)} · ${escapeHtml(b.customer_phone)}</small><p>${escapeHtml(b.pickup)} → ${escapeHtml(b.destination)}</p><b>${b.estimated_fare} ETB</b><button class="btn btn-primary" data-accept="${b.id}">Aqbal dalabka</button></article>`).join(""):"<p>Hadda ma jiraan dalabyo cusub.</p>"}</div><h3>Safarradayda</h3><div class="dashboard-wrap"><table class="dashboard-table"><thead><tr><th>Dalab</th><th>Safar</th><th>Xaalad</th><th>Ficil</th></tr></thead><tbody>${data.mine.map(b=>`<tr><td>${b.reference}</td><td>${escapeHtml(b.pickup)} → ${escapeHtml(b.destination)}</td><td>${statusSo[b.status]||b.status}</td><td>${b.status==="accepted"?`<button class="btn btn-ghost" data-status="${b.id}" data-next="arriving">Waan soo socdaa</button>`:b.status==="arriving"?`<button class="btn btn-ghost" data-status="${b.id}" data-next="in_progress">Bilow safarka</button>`:b.status==="in_progress"?`<button class="btn btn-primary" data-status="${b.id}" data-next="completed">Dhammee</button>`:"—"}</td></tr>`).join("")}</tbody></table></div>`);
 $("#toggleOnline").addEventListener("click",async()=>{try{const d=await api("/api/driver/online",{method:"POST",body:JSON.stringify({online:!currentUser.online})});currentUser.online=d.online;renderDriver()}catch(e){alert(e.message)}});
 }catch(e){openModal(`${dashboardHeader("Dashboard-ka darawalka")}<div class="result error">${escapeHtml(e.message)}</div>`)}
}
document.addEventListener("click",async e=>{
 if(e.target.dataset.accept){try{await api(`/api/driver/bookings/${e.target.dataset.accept}/accept`,{method:"POST",body:"{}"});renderDriver()}catch(err){alert(err.message)}}
 if(e.target.dataset.status){try{await api(`/api/driver/bookings/${e.target.dataset.status}/status`,{method:"POST",body:JSON.stringify({status:e.target.dataset.next})});renderDriver()}catch(err){alert(err.message)}}
 if(e.target.dataset.approve){try{await api(`/api/admin/drivers/${e.target.dataset.approve}/approve`,{method:"POST",body:JSON.stringify({approved:e.target.dataset.value==="1"})});renderAdmin()}catch(err){alert(err.message)}}
 if(e.target.dataset.assign){const driverId=prompt("Geli ID-ga darawalka la ansixiyey:");if(driverId){try{await api(`/api/admin/bookings/${e.target.dataset.assign}/assign`,{method:"POST",body:JSON.stringify({driverId:Number(driverId)})});renderAdmin()}catch(err){alert(err.message)}}}
 if(e.target.dataset.cancel){try{await api(`/api/admin/bookings/${e.target.dataset.cancel}/cancel`,{method:"POST",body:"{}"});renderAdmin()}catch(err){alert(err.message)}}
});
async function renderAdmin(){
 try{
 const d=await api("/api/admin/overview"),c=d.counts;
 openModal(`${dashboardHeader("Maamulka Jigjiga Bajaj")}<button class="btn btn-ghost" id="refreshDash">Cusboonaysii</button><div class="dash-cards"><div class="dash-card"><small>Dalabyo</small><strong>${c.total||0}</strong></div><div class="dash-card"><small>Sugaya</small><strong>${c.pending||0}</strong></div><div class="dash-card"><small>Safarro socda</small><strong>${c.active||0}</strong></div><div class="dash-card"><small>Dhammaaday</small><strong>${c.completed||0}</strong></div><div class="dash-card"><small>Qiimaha safarrada dhammaaday</small><strong>${Number(c.revenue||0).toFixed(0)} ETB</strong></div></div><h3>Dejinta qiimaha</h3><form id="settingsForm" class="admin-settings"><label>Qiimaha bilowga (ETB)<input name="baseFare" type="number" min="0" step=".01" value="${d.settings.baseFare}" required></label><label>Qiimaha halkii km (ETB)<input name="perKmFare" type="number" min="0" step=".01" value="${d.settings.perKmFare}" required></label><label class="full">Telefoonka ganacsiga<input name="businessPhone" value="${escapeHtml(d.settings.businessPhone)}" placeholder="Ku dar lambarka WhatsApp haddii la rabo"></label><label class="full"><input name="serviceEnabled" type="checkbox" ${d.settings.serviceEnabled?"checked":""} style="width:auto;display:inline"> Adeeggu wuu furan yahay</label><button class="btn btn-primary full">Kaydi dejinta</button><div id="settingsResult" class="result full"></div></form><h3>Darawallada</h3><div class="dashboard-wrap"><table class="dashboard-table"><thead><tr><th>ID</th><th>Magac / telefoon</th><th>Gaadiid</th><th>Xaalad</th><th>Ficil</th></tr></thead><tbody>${d.drivers.map(x=>`<tr><td>${x.id}</td><td>${escapeHtml(x.name)}<br>${escapeHtml(x.phone)}</td><td>${escapeHtml(x.vehicle_plate||"")} ${escapeHtml(x.vehicle_model||"")}</td><td>${x.approved?"La ansixiyey":"Sugaya"} · ${x.online?"Online":"Offline"}</td><td><button class="btn btn-ghost" data-approve="${x.id}" data-value="${x.approved?"0":"1"}">${x.approved?"Hakiji":"Ansixi"}</button></td></tr>`).join("")||"<tr><td colspan='5'>Weli darawal lama diiwaangelin.</td></tr>"}</tbody></table></div><h3>Dalabyadii ugu dambeeyey</h3><div class="dashboard-wrap"><table class="dashboard-table"><thead><tr><th>Ref</th><th>Macmiil</th><th>Safar</th><th>Xaalad</th><th>Ficil</th></tr></thead><tbody>${d.bookings.map(b=>`<tr><td>${b.reference}</td><td>${escapeHtml(b.customer_name)}<br>${escapeHtml(b.customer_phone)}</td><td>${escapeHtml(b.pickup)} → ${escapeHtml(b.destination)}<br>${b.estimated_fare} ETB</td><td>${statusSo[b.status]||b.status}<br>${escapeHtml(b.driver_name||"Darawal ma jiro")}</td><td>${b.status==="pending"?`<button class="btn btn-ghost" data-assign="${b.id}">Qoondee darawal</button>`:""} ${!["completed","cancelled"].includes(b.status)?`<button class="btn btn-ghost" data-cancel="${b.id}">Jooji</button>`:"—"}</td></tr>`).join("")||"<tr><td colspan='5'>Weli dalab ma jiro.</td></tr>"}</tbody></table></div>`);
 $("#settingsForm").addEventListener("submit",async e=>{e.preventDefault();const f=e.currentTarget;try{const vals=Object.fromEntries(new FormData(f).entries());vals.serviceEnabled=f.serviceEnabled.checked;const r=await api("/api/admin/settings",{method:"POST",body:JSON.stringify(vals)});showResult($("#settingsResult"),"Dejinta waa la kaydiyey.",true);$("#fare").textContent=`${r.settings.baseFare} ETB`}catch(err){showResult($("#settingsResult"),err.message)}});
 }catch(e){openModal(`${dashboardHeader("Maamulka")}<div class="result error">${escapeHtml(e.message)}</div>`)}
}
(async()=>{try{const me=await api("/api/me");currentUser=me.user;if(currentUser)renderDashboard()}catch(e){}})();
