require("dotenv").config();
const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "jigjiga-bajaj.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 phone TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('admin','driver')),
 approved INTEGER NOT NULL DEFAULT 0,
 vehicle_plate TEXT,
 vehicle_model TEXT,
 online INTEGER NOT NULL DEFAULT 0,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS bookings (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 reference TEXT NOT NULL UNIQUE,
 customer_name TEXT NOT NULL,
 customer_phone TEXT NOT NULL,
 pickup TEXT NOT NULL,
 destination TEXT NOT NULL,
 notes TEXT DEFAULT '',
 estimated_fare REAL NOT NULL,
 final_fare REAL,
 status TEXT NOT NULL DEFAULT 'pending',
 driver_id INTEGER REFERENCES users(id),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS settings (
 key TEXT PRIMARY KEY,
 value TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_driver ON bookings(driver_id);
`);

const defaultSettings = {
 base_fare: String(Number(process.env.BASE_FARE || 40)),
 per_km_fare: String(Number(process.env.PER_KM_FARE || 12)),
 service_enabled: "1",
 business_phone: process.env.BUSINESS_PHONE || ""
};
for (const [key, value] of Object.entries(defaultSettings)) {
 db.prepare("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)").run(key, value);
}

function setting(key) {
 const row = db.prepare("SELECT value FROM settings WHERE key=?").get(key);
 return row ? row.value : "";
}
function publicSettings() {
 return {
  baseFare: Number(setting("base_fare") || 40),
  perKmFare: Number(setting("per_km_fare") || 12),
  serviceEnabled: setting("service_enabled") === "1",
  businessPhone: setting("business_phone") || ""
 };
}
function createAdmin() {
 const phone = process.env.ADMIN_PHONE;
 const password = process.env.ADMIN_PASSWORD;
 if (!phone || !password) return;
 const exists = db.prepare("SELECT id FROM users WHERE phone=?").get(phone);
 if (!exists) {
  const hash = bcrypt.hashSync(password, 12);
  db.prepare("INSERT INTO users(name,phone,password_hash,role,approved) VALUES(?,?,?,?,1)")
   .run(process.env.ADMIN_NAME || "Administrator", phone, hash, "admin");
  console.log("Initial admin account created from environment configuration.");
 }
}
createAdmin();

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false, limit: "100kb" }));
app.use(session({
 name: "jb.sid",
 secret: process.env.SESSION_SECRET || "development-only-change-this-secret",
 resave: false,
 saveUninitialized: false,
 store: new SQLiteStore({ db: "sessions.sqlite", dir: dataDir }),
 cookie: {
  httpOnly: true, sameSite: "lax",
  secure: process.env.NODE_ENV === "production",
  maxAge: 1000 * 60 * 60 * 12
 }
}));
app.use("/api/", rateLimit({ windowMs: 15 * 60 * 1000, limit: 250, standardHeaders: "draft-7", legacyHeaders: false }));
app.use(express.static(path.join(__dirname, "public")));

function auth(req, res, next) {
 if (!req.session.user) return res.status(401).json({ error: "Fadlan marka hore gal akoonkaaga." });
 next();
}
function role(...roles) {
 return (req, res, next) => {
  if (!req.session.user || !roles.includes(req.session.user.role)) return res.status(403).json({ error: "Ma lihid oggolaanshaha hawshan." });
  next();
 };
}
function safeUser(u) {
 return { id: u.id, name: u.name, phone: u.phone, role: u.role, approved: !!u.approved, vehiclePlate: u.vehicle_plate || "", vehicleModel: u.vehicle_model || "", online: !!u.online };
}
function validText(v, max=160) {
 return typeof v === "string" && v.trim().length > 0 && v.trim().length <= max;
}
function reference() {
 return "JB-" + crypto.randomBytes(3).toString("hex").toUpperCase();
}
function estimatedFare() {
 // No route-distance API is configured yet, so show the configured base fare as a provisional estimate.
 // The final fare must be confirmed by the driver/admin until distance calculation is integrated.
 return Math.max(0, Number(setting("base_fare") || 40));
}

app.get("/api/health", (req,res) => res.json({ ok: true, app: "Jigjiga Bajaj" }));
app.get("/api/settings", (req,res) => res.json(publicSettings()));
app.get("/api/me", (req,res) => res.json({ user: req.session.user || null }));

app.post("/api/bookings", (req,res) => {
 if (setting("service_enabled") !== "1") return res.status(503).json({ error: "Dalabku hadda wuu xiran yahay. Fadlan mar dambe isku day." });
 const { name, phone, pickup, destination, notes="" } = req.body || {};
 if (![name,phone,pickup,destination].every(v => validText(v))) return res.status(400).json({ error: "Buuxi magaca, telefoonka, meesha lagaa qaadayo iyo meesha aad u socoto." });
 if (!/^[+0-9 ()-]{7,20}$/.test(phone.trim())) return res.status(400).json({ error: "Fadlan geli lambar telefoon oo sax ah." });
 if (pickup.trim().toLowerCase() === destination.trim().toLowerCase()) return res.status(400).json({ error: "Meesha laga baxayo iyo meesha loo socdo isku mid ma noqon karaan." });
 if (typeof notes !== "string" || notes.length > 500) return res.status(400).json({ error: "Faahfaahinta dheeraadka ahi aad bay u dheer tahay." });
 let ref = reference();
 while (db.prepare("SELECT id FROM bookings WHERE reference=?").get(ref)) ref = reference();
 const fare = estimatedFare();
 const result = db.prepare(`INSERT INTO bookings(reference,customer_name,customer_phone,pickup,destination,notes,estimated_fare)
 VALUES(?,?,?,?,?,?,?)`).run(ref,name.trim(),phone.trim(),pickup.trim(),destination.trim(),notes.trim(),fare);
 res.status(201).json({ ok: true, reference: ref, estimatedFare: fare, currency: "ETB", message: "Dalabka waa la diiwaangeliyey. Sug inta darawal laguu raadinayo." });
});

app.get("/api/bookings/:reference", (req,res) => {
 const b = db.prepare(`SELECT reference,customer_name,pickup,destination,notes,estimated_fare,final_fare,status,created_at,updated_at,driver_id FROM bookings WHERE reference=?`).get(req.params.reference.toUpperCase());
 if (!b) return res.status(404).json({ error: "Dalabkan lama helin." });
 let driver = null;
 if (b.driver_id) {
  const d = db.prepare("SELECT name,phone,vehicle_plate,vehicle_model FROM users WHERE id=?").get(b.driver_id);
  if (d) driver = { name:d.name, phone:d.phone, vehiclePlate:d.vehicle_plate || "", vehicleModel:d.vehicle_model || "" };
 }
 res.json({ booking: { ...b, driver } });
});

app.post("/api/register-driver", (req,res) => {
 const { name, phone, password, vehiclePlate, vehicleModel } = req.body || {};
 if (![name,phone,password,vehiclePlate,vehicleModel].every(v => validText(v,160))) return res.status(400).json({ error: "Buuxi dhammaan meelaha loo baahan yahay." });
 if (!/^[+0-9 ()-]{7,20}$/.test(phone.trim())) return res.status(400).json({ error: "Lambarka telefoonka sax." });
 if (password.length < 10) return res.status(400).json({ error: "Furaha sirta ahi waa inuu ugu yaraan 10 xaraf noqdaa." });
 try {
  const hash = bcrypt.hashSync(password, 12);
  db.prepare("INSERT INTO users(name,phone,password_hash,role,approved,vehicle_plate,vehicle_model) VALUES(?,?,?,?,0,?,?)")
   .run(name.trim(),phone.trim(),hash,"driver",vehiclePlate.trim(),vehicleModel.trim());
  res.status(201).json({ ok:true, message:"Codsigaaga darawalnimo waa la helay. Maamulka ayaa dib u eegi doona ka hor intaadan safarro aqbalin." });
 } catch(e) {
  if (String(e.message).includes("UNIQUE")) return res.status(409).json({ error:"Lambarkan hore ayaa loo diiwaangeliyey." });
  console.error(e); res.status(500).json({ error:"Diiwaangelintu way fashilantay." });
 }
});

app.post("/api/login", (req,res) => {
 const { phone, password } = req.body || {};
 if (!validText(phone,30) || !validText(password,200)) return res.status(400).json({ error:"Geli telefoonka iyo furaha sirta." });
 const u = db.prepare("SELECT * FROM users WHERE phone=?").get(phone.trim());
 if (!u || !bcrypt.compareSync(password, u.password_hash)) return res.status(401).json({ error:"Telefoonka ama furaha sirta ayaa khaldan." });
 if (u.role === "driver" && !u.approved) return res.status(403).json({ error:"Akoonkaaga wali maamulka ma ansixin." });
 req.session.regenerate(err => {
  if (err) return res.status(500).json({ error:"Gelitaanka waa fashilmay." });
  req.session.user = safeUser(u);
  res.json({ ok:true, user:req.session.user });
 });
});
app.post("/api/logout", (req,res) => req.session.destroy(() => { res.clearCookie("jb.sid"); res.json({ok:true}); }));

app.get("/api/driver/bookings", auth, role("driver"), (req,res) => {
 const u = req.session.user;
 const available = db.prepare(`SELECT id,reference,customer_name,customer_phone,pickup,destination,notes,estimated_fare,status,created_at
 FROM bookings WHERE status='pending' AND driver_id IS NULL ORDER BY id ASC LIMIT 100`).all();
 const mine = db.prepare(`SELECT id,reference,customer_name,customer_phone,pickup,destination,notes,estimated_fare,final_fare,status,created_at,updated_at
 FROM bookings WHERE driver_id=? ORDER BY id DESC LIMIT 100`).all(u.id);
 res.json({ available, mine });
});
app.post("/api/driver/online", auth, role("driver"), (req,res) => {
 const online = !!(req.body && req.body.online);
 db.prepare("UPDATE users SET online=? WHERE id=?").run(online?1:0,req.session.user.id);
 req.session.user.online = online;
 res.json({ok:true,online});
});
app.post("/api/driver/bookings/:id/accept", auth, role("driver"), (req,res) => {
 const u = db.prepare("SELECT * FROM users WHERE id=?").get(req.session.user.id);
 if (!u || !u.approved) return res.status(403).json({error:"Akoonka darawalka lama ansixin."});
 const active = db.prepare("SELECT id FROM bookings WHERE driver_id=? AND status IN ('accepted','arriving','in_progress')").get(u.id);
 if (active) return res.status(409).json({error:"Waxaad hore u leedahay safar aan dhammaan."});
 const result = db.prepare(`UPDATE bookings SET driver_id=?,status='accepted',updated_at=CURRENT_TIMESTAMP
 WHERE id=? AND status='pending' AND driver_id IS NULL`).run(u.id,Number(req.params.id));
 if (!result.changes) return res.status(409).json({error:"Dalabkan darawal kale ayaa qaatay ama lama heli karo."});
 res.json({ok:true,message:"Dalabka waad aqbashay."});
});
app.post("/api/driver/bookings/:id/status", auth, role("driver"), (req,res) => {
 const allowed = ["arriving","in_progress","completed"];
 const status = req.body && req.body.status;
 if (!allowed.includes(status)) return res.status(400).json({error:"Xaaladda la doortay sax ma aha."});
 const b = db.prepare("SELECT * FROM bookings WHERE id=? AND driver_id=?").get(Number(req.params.id),req.session.user.id);
 if (!b) return res.status(404).json({error:"Dalabkan adiga laguma qoondeyn."});
 const transitions = {accepted:["arriving"],arriving:["in_progress"],in_progress:["completed"]};
 if (!(transitions[b.status] || []).includes(status)) return res.status(409).json({error:"Tallaabadan xaaladda lagama oggola."});
 db.prepare("UPDATE bookings SET status=?,final_fare=CASE WHEN ?='completed' THEN estimated_fare ELSE final_fare END,updated_at=CURRENT_TIMESTAMP WHERE id=?")
  .run(status,status,b.id);
 res.json({ok:true,status});
});

app.get("/api/admin/overview", auth, role("admin"), (req,res) => {
 const counts = db.prepare(`SELECT
 COUNT(*) total,
 SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) pending,
 SUM(CASE WHEN status IN ('accepted','arriving','in_progress') THEN 1 ELSE 0 END) active,
 SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) completed,
 SUM(CASE WHEN status='cancelled' THEN 1 ELSE 0 END) cancelled,
 COALESCE(SUM(CASE WHEN status='completed' THEN COALESCE(final_fare,estimated_fare) ELSE 0 END),0) revenue
 FROM bookings`).get();
 const drivers = db.prepare("SELECT id,name,phone,approved,vehicle_plate,vehicle_model,online,created_at FROM users WHERE role='driver' ORDER BY id DESC").all();
 const bookings = db.prepare(`SELECT b.*,u.name driver_name FROM bookings b LEFT JOIN users u ON u.id=b.driver_id ORDER BY b.id DESC LIMIT 300`).all();
 res.json({counts,drivers,bookings,settings:publicSettings()});
});
app.post("/api/admin/drivers/:id/approve", auth, role("admin"), (req,res) => {
 const approved = req.body && req.body.approved ? 1 : 0;
 const r = db.prepare("UPDATE users SET approved=? WHERE id=? AND role='driver'").run(approved,Number(req.params.id));
 if (!r.changes) return res.status(404).json({error:"Darawalka lama helin."});
 res.json({ok:true});
});
app.post("/api/admin/bookings/:id/assign", auth, role("admin"), (req,res) => {
 const driverId = Number(req.body && req.body.driverId);
 const d = db.prepare("SELECT id FROM users WHERE id=? AND role='driver' AND approved=1").get(driverId);
 if (!d) return res.status(400).json({error:"Dooro darawal la ansixiyey."});
 const r = db.prepare("UPDATE bookings SET driver_id=?,status='accepted',updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='pending' AND driver_id IS NULL").run(driverId,Number(req.params.id));
 if (!r.changes) return res.status(409).json({error:"Dalabka lama qoondeyn karo; waxaa laga yaabaa in la qaatay."});
 res.json({ok:true});
});
app.post("/api/admin/bookings/:id/cancel", auth, role("admin"), (req,res) => {
 const r = db.prepare("UPDATE bookings SET status='cancelled',updated_at=CURRENT_TIMESTAMP WHERE id=? AND status NOT IN ('completed','cancelled')").run(Number(req.params.id));
 if (!r.changes) return res.status(409).json({error:"Dalabkan lama joojin karo."});
 res.json({ok:true});
});
app.post("/api/admin/settings", auth, role("admin"), (req,res) => {
 const {baseFare,perKmFare,serviceEnabled,businessPhone} = req.body || {};
 if (!Number.isFinite(Number(baseFare)) || Number(baseFare)<0 || !Number.isFinite(Number(perKmFare)) || Number(perKmFare)<0) return res.status(400).json({error:"Qiimaha waa inuu noqdaa tiro aan tabanayn."});
 if (typeof businessPhone !== "string" || businessPhone.length>30) return res.status(400).json({error:"Telefoonka ganacsigu sax ma aha."});
 const put = db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
 const tx = db.transaction(() => {
  put.run("base_fare",String(Number(baseFare)));
  put.run("per_km_fare",String(Number(perKmFare)));
  put.run("service_enabled",serviceEnabled ? "1":"0");
  put.run("business_phone",businessPhone.trim());
 });
 tx(); res.json({ok:true,settings:publicSettings()});
});

app.get("*", (req,res) => res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT, () => console.log(`Jigjiga Bajaj running at http://localhost:${PORT}`));
